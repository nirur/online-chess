/* WebRTC player-opponent video call connection */
/*
var stream = null;
        navigator.getUserMedia({video:true, audio:true},
            function(gotStream){stream=gotStream},
            function(err){console.log(err)});
*/